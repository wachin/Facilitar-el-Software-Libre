#! /bin/sh

if [[ $EUID -eq 0 ]]; then
    bin_dir="$(kf5-config --path exe | sed "s/.*://")"
    desktop_dir="$(kf5-config --path services | sed "s/.*://")ServiceMenus/"
    doc_dir="/usr/share/doc/kde-service-menu-encfs/"
    echo "Installing kde-service-menu-encfs system wide"
else
    bin_dir="$HOME/bin"
    desktop_dir="$(kf5-config --path services | sed "s/:.*//")"
    doc_dir=$HOME"/share/doc/kde-service-menu-encfs/"
    echo "Installing kde-service-menu-encfs locally"
fi

if [ ! -d "${bin_dir}" ]; then
    echo "Making directory ${bin_dir}"
    mkdir -p "${bin_dir}"
fi
echo "Copy files to ${bin_dir}"
cp bin/encfs-kdialog ${bin_dir}

if [ ! -d "${desktop_dir}" ]; then
    echo "Making directory ${desktop_dir}"
    mkdir -p "${desktop_dir}"
fi
echo "Copy files to ${desktop_dir}"
cp ServiceMenus/encfs.desktop ${desktop_dir}

if [ ! -d "${doc_dir}" ]; then
    echo "Making directory ${doc_dir}"
    mkdir -p "${doc_dir}"
fi
echo "Copy files to ${doc_dir}"
cp doc/* ${doc_dir}

echo "Done!"
