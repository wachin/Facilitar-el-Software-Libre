LibreOffice-KDE4-Templates.zip
Version: 0.3
Author: Michael van Gemmern
Discription:
 These files are templates and context menus for KDE 4.x
 and original LibreOffice 3. Now you can right click in
 konqueror or on the desktop and generate a new file.
Requirements:
 LibreOffice Vers. 3.x from www.libreoffice.org
 KDE 4.x

Content:
 /readme.txt
 /usr/share/kde4/templates/LO-Calc.desktop
 /usr/share/kde4/templates/LO-Draw.desktop
 /usr/share/kde4/templates/LO-Impress.desktop
 /usr/share/kde4/templates/LO-Writer.desktop
 /usr/share/kde4/templates/.source/Praesentation.odp
 /usr/share/kde4/templates/.source/TabellenDokument.ods
 /usr/share/kde4/templates/.source/TextDokument.odt
 /usr/share/kde4/templates/.source/Zeichnung.odg

Installation:
 Just copy the directory "usr" to your /. You need root
 privilegies.

Usage:
 Just right click on your desktop and select f.e. "New|LO-Calc"
 choose a name with extension ods and you'll get a new one.

Version history:
 0.1:	Initial relase
 0.2:	Added version for LibreOffice
 0.2.1	Added version for Mandriva
 0.3	Added extensions as hints to File-Create-Dialog.

Hints:
 I've modified the files from koffice, so there may be some
 translation errors. You have to allow to overwrite the existing
 files. This happens because of the existing dir /usr or having
 installed an older version of these tenplates.
